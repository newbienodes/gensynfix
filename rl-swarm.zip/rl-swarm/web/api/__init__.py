"""
API package for the web server.
"""
